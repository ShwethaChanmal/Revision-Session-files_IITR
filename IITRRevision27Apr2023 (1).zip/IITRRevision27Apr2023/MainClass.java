package com.gl.oopscoll;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DerivedClass dc = new DerivedClass();
		dc.display();
		dc.display();

	}

}
