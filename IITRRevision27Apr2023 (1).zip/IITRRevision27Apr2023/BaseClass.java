package com.gl.oopscoll;

public class BaseClass {
	public void display()
	{
		System.out.println("Displaying Base Class Features....");
	}

}
