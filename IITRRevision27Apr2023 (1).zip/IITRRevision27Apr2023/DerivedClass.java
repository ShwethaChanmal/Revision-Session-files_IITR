package com.gl.oopscoll;

public class DerivedClass extends BaseClass{
	
	public void display()
	{
		System.out.println("Displaying Derived Class Features....");
	}

}
