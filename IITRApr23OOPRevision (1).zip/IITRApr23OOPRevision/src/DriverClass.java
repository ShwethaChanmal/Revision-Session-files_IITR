
public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PermanentEmployee suman = new PermanentEmployee();
		suman.acceptPEmployeeDetails();
		suman.displayPEmployeeDetails();
		
		TemporaryEmployee suresh = new TemporaryEmployee();
		suresh.acceptTEmployeeDetails();
		suresh.displayTEmployeeDetails();

	}

}
