
public class PermanentEmployee  extends Employee{
	
	float salary;
	public void acceptPEmployeeDetails()
	{
		acceptEmployeeDetails();
		super.acceptEmployeeDetails();
	}
	public void displayPEmployeeDetails()
	{
		super.displayEmployeeDetails();
	}

}
