
public class Employee {
	
	String employeeId;
	String employeeName;
	String employeeAddress;
	String department;
	
	public void acceptEmployeeDetails()
	{
		
		
	}
	public void displayEmployeeDetails()
	{
		
	}

}
