
public class TemporaryEmployee extends Employee{
	
	float wagePerHour;
	public void acceptTEmployeeDetails()
	{
		super.acceptEmployeeDetails();
	}
	public void displayTEmployeeDetails()
	{
		super.displayEmployeeDetails();
	}

}
