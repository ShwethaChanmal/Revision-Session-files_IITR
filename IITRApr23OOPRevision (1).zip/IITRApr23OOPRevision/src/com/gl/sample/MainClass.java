package com.gl.sample;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent p = (Parent) new Child();
		p.salary = 1000;
		p.display();
		
		Child c = new Child();
		c.salary = 1200;
		c.display();
		
		// Child  c1 = (Child)new Parent(); ClassCast
	}

}
