package com.gl.sample;

public class SBAccount extends MyAccount{

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("Interest Calculated for SB ac");
	}

}
