package com.gl.sample;

public class Parent {
	
	int salary=1000;
	
	public void display()
	{
		System.out.println("The Salary is "+salary);
	}

}
