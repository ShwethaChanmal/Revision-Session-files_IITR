package com.gl.sample;

public abstract class MyAccount {
	
	public abstract void calculateInterest() ;
	
	public void displayAccount()
	{
		System.out.println("Displaying Account Details");
		
	}
	public void xyz()
	{
		
	}

}
