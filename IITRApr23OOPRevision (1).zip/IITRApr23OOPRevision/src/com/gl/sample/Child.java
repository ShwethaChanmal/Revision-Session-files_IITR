package com.gl.sample;

public class Child extends Parent {

	int salary;
	
	public void display()
	{
		System.out.println("Salary of Child is "+salary);
	}
}
