package com.gl.sample;

public class CreditCardAccount implements Account{

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
	//	rate = 10;
		System.out.println("Interest For Credt Card calculated");
		System.out.println("Rate is "+rate);
	}

	@Override
	public void calculateOutstanding() {
		// TODO Auto-generated method stub
		System.out.println("Outsanding for CC act is ");
	}

}
