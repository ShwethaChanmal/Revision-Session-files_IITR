package com.gl.sample;

public interface Account {

	int rate = 10;
	public void calculateInterest();
	public void calculateOutstanding();
}
