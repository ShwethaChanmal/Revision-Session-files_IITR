package com.gl.sample;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	MyAccount mac = new MyAccount();
		SBAccount sba = new SBAccount();
		sba.calculateInterest();
		sba.displayAccount();
	}

}
